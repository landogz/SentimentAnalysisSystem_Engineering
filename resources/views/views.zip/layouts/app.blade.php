<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <title>@yield('title', 'Student Feedback System')</title>

    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/3.2.0/css/adminlte.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --dark-gray: #494850;
            --light-green: #8FCFA8;
            --coral-pink: #FF4E00;
            --golden-orange: #F5B445;
            --light-blue: #98AAE7;
        }

        .rating-stars {
            color: var(--golden-orange);
            font-size: 1.2em;
        }
        .sentiment-badge {
            font-size: 0.8em;
            padding: 0.25em 0.6em;
        }
        .card-stats {
            border-left: 4px solid var(--light-blue);
            transition: all 0.3s ease;
        }
        .card-stats:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(73, 72, 80, 0.1);
        }
        .card-stats.positive {
            border-left-color: var(--light-green);
        }
        .card-stats.negative {
            border-left-color: var(--coral-pink);
        }
        .card-stats.neutral {
            border-left-color: var(--golden-orange);
        }
        
        /* Enhanced Pagination Styling */
        .pagination {
            margin-bottom: 0;
            flex-wrap: wrap;
        }
        .page-link {
            color: var(--light-blue);
            border: 1px solid #dee2e6;
            padding: 0.5rem 0.75rem;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        .page-link:hover {
            color: var(--dark-gray);
            background-color: #e9ecef;
            border-color: #dee2e6;
            transform: translateY(-1px);
            text-decoration: none;
        }
        .page-item.active .page-link {
            background-color: var(--light-blue);
            border-color: var(--light-blue);
            color: white;
        }
        .page-item.disabled .page-link {
            color: #6c757d;
            background-color: #fff;
            border-color: #dee2e6;
            cursor: not-allowed;
        }
        .pagination-info {
            font-size: 0.875rem;
            color: #6c757d;
        }
        .page-item {
            margin: 0 0.125rem;
        }

        /* Enhanced Table Styling */
        .table {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(73, 72, 80, 0.1);
        }
        .table thead th {
            background-color: var(--golden-orange);
            border-bottom: 2px solid #dee2e6;
            font-weight: 600;
            color: white;
        }
        .table tbody tr:hover {
            background-color: rgba(143, 207, 168, 0.1);
            transition: background-color 0.2s ease;
        }

        /* Enhanced Modal Styling */
        .modal-content {
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(73, 72, 80, 0.2);
        }
        .modal-header {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--coral-pink) 100%);
            color: white;
            border-radius: 12px 12px 0 0;
        }
        .modal-header .close {
            color: white;
            opacity: 0.8;
        }
        .modal-header .close:hover {
            opacity: 1;
        }

        /* Enhanced Button Styling */
        .btn {
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(73, 72, 80, 0.1);
        }
        .btn-primary {
            background-color: var(--light-blue);
            border-color: var(--light-blue);
        }
        .btn-primary:hover {
            background-color: #7a8cd6;
            border-color: #7a8cd6;
        }
        .btn-success {
            background-color: var(--light-green);
            border-color: var(--light-green);
        }
        .btn-success:hover {
            background-color: #7bb894;
            border-color: #7bb894;
        }
        .btn-danger {
            background-color: var(--coral-pink);
            border-color: var(--coral-pink);
        }
        .btn-danger:hover {
            background-color: #E64500;
            border-color: #E64500;
        }
        .btn-warning {
            background-color: var(--golden-orange);
            border-color: var(--golden-orange);
        }
        .btn-warning:hover {
            background-color: #e4a23d;
            border-color: #e4a23d;
        }

        /* Enhanced Card Styling */
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(73, 72, 80, 0.1);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(73, 72, 80, 0.15);
        }

        /* Enhanced Form Styling */
        .form-control {
            border-radius: 6px;
            border: 2px solid #e9ecef;
            transition: all 0.2s ease;
        }
        .form-control:focus {
            border-color: var(--light-blue);
            box-shadow: 0 0 0 0.2rem rgba(152, 170, 231, 0.25);
        }

        /* Enhanced Badge Styling */
        .badge {
            border-radius: 12px;
            font-weight: 500;
            padding: 0.5em 0.8em;
        }
        .badge-primary {
            background-color: var(--light-blue);
        }
        .badge-success {
            background-color: var(--light-green);
        }
        .badge-danger {
            background-color: var(--coral-pink);
        }
        .badge-warning {
            background-color: var(--golden-orange);
        }

        /* Hide Sidebar */
        .main-sidebar {
            display: none !important;
        }

        /* Horizontal Navigation Menu */
        .horizontal-nav {
            background: linear-gradient(135deg, var(--dark-gray) 0%, #5a5a6a 100%);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 0;
            border-bottom: 3px solid var(--light-blue);
            position: sticky;
            top: 0;
            z-index: 1030;
        }
        
        .horizontal-nav .container-fluid {
            padding: 0;
        }
        
        .horizontal-nav .navbar-nav {
            flex-direction: row;
            width: 100%;
            justify-content: center;
            align-items: center;
            gap: 0.25rem;
            padding: 0.75rem 1rem;
            flex-wrap: wrap;
        }
        
        .horizontal-nav .nav-item {
            position: relative;
        }
        
        .horizontal-nav .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            padding: 0.875rem 1.5rem !important;
            border-radius: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 600;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
            position: relative;
            white-space: nowrap;
            font-family: 'Poppins', sans-serif;
        }
        
        .horizontal-nav .nav-link i {
            font-size: 1.05rem;
            width: 22px;
            text-align: center;
        }
        
        .horizontal-nav .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .horizontal-nav .nav-link.active {
            background: linear-gradient(135deg, var(--coral-pink) 0%, #E64500 100%);
            color: white !important;
            box-shadow: 0 6px 20px rgba(255, 78, 0, 0.5);
            font-weight: 700;
        }
        
        .horizontal-nav .navbar-toggler {
            margin: 0.5rem 1rem;
        }
        
        .horizontal-nav .navbar-toggler:focus {
            box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
        }

        /* Enhanced Navbar */
        .main-header {
            box-shadow: 0 2px 8px rgba(73, 72, 80, 0.1);
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border-bottom: 1px solid #e9ecef;
        }
        
        .main-header .navbar-nav .nav-link {
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        
        .main-header .navbar-nav .nav-link:hover {
            background-color: rgba(152, 170, 231, 0.1);
        }

        /* Enhanced Content Area */
        .content-wrapper {
            background: linear-gradient(135deg, #f5f7fa 0%, rgba(152, 170, 231, 0.1) 100%);
            min-height: 100vh;
            padding: 20px;
            margin-left: 0 !important;
        }
        
        /* Override AdminLTE sidebar margin */
        body .content-wrapper,
        body .main-footer,
        body .main-header {
            margin-left: 0 !important;
        }
        
        @media (min-width: 768px) {
            body:not(.sidebar-mini-md):not(.sidebar-mini-xs):not(.layout-top-nav) .content-wrapper,
            body:not(.sidebar-mini-md):not(.sidebar-mini-xs):not(.layout-top-nav) .main-footer,
            body:not(.sidebar-mini-md):not(.sidebar-mini-xs):not(.layout-top-nav) .main-header {
                margin-left: 0 !important;
            }
        }
        
        /* Logo in Navbar */
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 700;
            font-size: 1.3rem;
            color: var(--dark-gray) !important;
            padding: 0.5rem 1rem;
        }
        
        .navbar-brand img {
            height: 45px;
            width: auto;
        }
        
        .navbar-brand:hover {
            color: var(--light-blue) !important;
        }

        /* Enhanced Stats Cards */
        .small-box {
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        .small-box:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(73, 72, 80, 0.15);
        }
        .small-box.bg-info {
            background-color: var(--light-blue) !important;
        }
        .small-box.bg-success {
            background-color: var(--light-green) !important;
        }
        .small-box.bg-warning {
            background-color: var(--golden-orange) !important;
        }
        .small-box.bg-danger {
            background-color: var(--coral-pink) !important;
        }

        /* Enhanced Search Box */
        .search-box {
            border-radius: 25px;
            border: 2px solid #e9ecef;
            transition: all 0.2s ease;
        }
        .search-box:focus {
            border-color: var(--light-blue);
            box-shadow: 0 0 0 0.2rem rgba(152, 170, 231, 0.25);
        }

        /* Brand Logo Styling */
        .brand-link .brand-image {
            color: var(--light-blue) !important;
        }

        /* Alert Styling */
        .alert-success {
            background-color: var(--light-green);
            border-color: var(--light-green);
            color: var(--dark-gray);
        }
        .alert-danger {
            background-color: var(--coral-pink);
            border-color: var(--coral-pink);
            color: white;
        }
        .alert-warning {
            background-color: var(--golden-orange);
            border-color: var(--golden-orange);
            color: var(--dark-gray);
        }
        .alert-info {
            background-color: var(--light-blue);
            border-color: var(--light-blue);
            color: white;
        }

        /* Text Colors */
        .text-primary {
            color: var(--light-blue) !important;
        }
        .text-success {
            color: var(--light-green) !important;
        }
        .text-danger {
            color: var(--coral-pink) !important;
        }
        .text-warning {
            color: var(--golden-orange) !important;
        }
        .text-muted {
            color: var(--dark-gray) !important;
        }

        /* Progress Bar Styling */
        .progress-bar.bg-primary {
            background-color: var(--light-blue) !important;
        }
        .progress-bar.bg-success {
            background-color: var(--light-green) !important;
        }
        .progress-bar.bg-danger {
            background-color: var(--coral-pink) !important;
        }
        .progress-bar.bg-warning {
            background-color: var(--golden-orange) !important;
        }

        /* Content Header Professional Design */
        .content-header {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(248, 249, 250, 0.95) 100%);
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-bottom: 3px solid transparent;
            border-image: linear-gradient(135deg, var(--light-blue) 0%, var(--coral-pink) 100%) 1;
            position: relative;
            overflow: hidden;
        }

        .content-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--light-blue) 0%, var(--coral-pink) 50%, var(--light-green) 100%);
            background-size: 200% 100%;
            animation: gradientShift 3s ease infinite;
        }

        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .content-header::after {
            content: '';
            position: absolute;
            top: 0;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(152, 170, 231, 0.05) 0%, transparent 70%);
            pointer-events: none;
        }

        /* Page Title Styling */
        .page-title-custom {
            font-family: 'Poppins', 'Source Sans Pro', sans-serif;
            font-weight: 700;
            font-size: 2.5rem;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 1rem;
            position: relative;
            z-index: 1;
        }

        .page-title-custom::before {
            content: '';
            position: absolute;
            left: -1.5rem;
            top: 50%;
            transform: translateY(-50%);
            width: 5px;
            height: 60%;
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--coral-pink) 100%);
            border-radius: 10px;
        }

        .page-title-custom i {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--coral-pink) 0%, #E64500 100%);
            color: white;
            border-radius: 16px;
            font-size: 1.8rem;
            box-shadow: 0 8px 20px rgba(255, 78, 0, 0.3);
            transition: all 0.3s ease;
        }

        .page-title-custom:hover i {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 12px 30px rgba(255, 78, 0, 0.4);
        }

        .page-title-custom span {
            background: linear-gradient(135deg, var(--dark-gray) 0%, #6a6a7a 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            position: relative;
        }

        /* Breadcrumb Professional Design */
        .breadcrumb {
            background: transparent;
            padding: 0;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 0.5rem;
            font-size: 0.95rem;
        }

        .breadcrumb-item {
            display: flex;
            align-items: center;
        }

        .breadcrumb-item + .breadcrumb-item::before {
            content: '\f105';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            color: var(--light-blue);
            padding: 0 0.75rem;
            font-size: 0.9rem;
        }

        .breadcrumb-item a {
            color: var(--dark-gray);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .breadcrumb-item a:hover {
            background: linear-gradient(135deg, rgba(152, 170, 231, 0.1) 0%, rgba(143, 207, 168, 0.1) 100%);
            color: var(--light-blue);
            transform: translateX(-2px);
        }

        .breadcrumb-item.active {
            color: var(--dark-gray);
            font-weight: 600;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, rgba(152, 170, 231, 0.15) 0%, rgba(143, 207, 168, 0.15) 100%);
            border-radius: 8px;
            position: relative;
        }

        .breadcrumb-item.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 2px;
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--coral-pink) 100%);
            border-radius: 2px;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            /* Navbar Mobile Optimizations */
            .main-header {
                padding: 0.5rem 1rem;
            }
            .navbar-nav .nav-link {
                padding: 0.75rem 1rem;
                font-size: 0.9rem;
            }
            .navbar-nav .nav-link.btn {
                padding: 0.5rem 1rem;
                font-size: 0.85rem;
                margin: 0.25rem 0;
            }
            .dropdown-menu {
                position: fixed !important;
                top: 60px !important;
                left: 0 !important;
                right: 0 !important;
                width: 100% !important;
                border-radius: 0 !important;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2) !important;
            }
            
            /* Horizontal Nav Mobile Optimizations */
            .horizontal-nav {
                position: relative;
            }
            
            .horizontal-nav .navbar-nav {
                flex-direction: column;
                width: 100%;
                gap: 0.5rem;
                padding: 1rem;
                background: rgba(0, 0, 0, 0.1);
                border-radius: 0 0 12px 12px;
            }
            
            .horizontal-nav .nav-link {
                padding: 0.875rem 1rem !important;
                font-size: 0.9rem !important;
                width: 100%;
                justify-content: flex-start;
            }
            
            .horizontal-nav .nav-link i {
                font-size: 1rem !important;
                width: 24px !important;
            }
            
            .navbar-brand span {
                font-size: 1.1rem !important;
            }
            
            /* Content Area Mobile Optimizations */
            .content-wrapper {
                padding: 10px !important;
                margin-left: 0 !important;
            }
            /* Content Header Mobile */
            .content-header {
                padding: 1.5rem 0 !important;
                margin-bottom: 1.5rem !important;
            }

            .page-title-custom {
                font-size: 1.8rem !important;
                margin-bottom: 0.5rem !important;
                flex-direction: column;
                align-items: flex-start !important;
                gap: 0.75rem !important;
            }

            .page-title-custom::before {
                display: none;
            }

            .page-title-custom i {
                width: 50px !important;
                height: 50px !important;
                font-size: 1.5rem !important;
            }

            .page-title-custom span {
                font-size: 1.8rem !important;
            }

            .breadcrumb {
                justify-content: flex-start !important;
                margin-top: 1rem;
                flex-wrap: wrap;
            }

            .breadcrumb-item {
                font-size: 0.85rem !important;
            }

            .breadcrumb-item a,
            .breadcrumb-item.active {
                padding: 0.4rem 0.75rem !important;
            }
            
            /* Cards Mobile Optimizations */
            .card {
                margin-bottom: 1rem !important;
                border-radius: 12px !important;
            }
            .card-header {
                padding: 1rem !important;
            }
            .card-body {
                padding: 1rem !important;
            }
            
            /* Statistics Cards Mobile */
            .small-box {
                margin-bottom: 1rem !important;
                min-height: 100px !important;
            }
            .small-box .inner {
                padding: 1rem !important;
            }
            .small-box .inner h3 {
                font-size: 1.8rem !important;
            }
            .small-box .inner p {
                font-size: 0.9rem !important;
            }
            
            /* Tables Mobile Optimizations */
            .table-responsive {
                border-radius: 12px !important;
                overflow: hidden !important;
            }
            .table {
                font-size: 0.9rem !important;
            }
            .table th,
            .table td {
                padding: 0.75rem 0.5rem !important;
                vertical-align: middle !important;
            }
            
            /* Forms Mobile Optimizations */
            .form-control,
            .form-select {
                font-size: 16px !important; /* Prevents zoom on iOS */
                padding: 0.75rem !important;
                border-radius: 8px !important;
            }
            .form-label {
                font-size: 0.95rem !important;
                margin-bottom: 0.5rem !important;
            }
            
            /* Buttons Mobile Optimizations */
            .btn {
                padding: 0.75rem 1.5rem !important;
                font-size: 0.9rem !important;
                border-radius: 8px !important;
                min-height: 44px !important; /* Touch target size */
            }
            .btn-sm {
                padding: 0.5rem 1rem !important;
                font-size: 0.85rem !important;
            }
            
            /* Pagination Mobile */
            .pagination {
                justify-content: center !important;
                flex-wrap: wrap !important;
                gap: 0.25rem !important;
            }
            .page-link {
                padding: 0.5rem 0.75rem !important;
                font-size: 0.9rem !important;
                min-width: 2.5rem !important;
                justify-content: center !important;
            }
            .page-item {
                margin: 0 !important;
            }
            
            /* Alerts Mobile */
            .alert {
                padding: 1rem !important;
                margin-bottom: 1rem !important;
                border-radius: 8px !important;
            }
            
            /* Modal Mobile Optimizations */
            .modal-dialog {
                margin: 0.5rem !important;
                max-width: calc(100% - 1rem) !important;
            }
            .modal-content {
                border-radius: 12px !important;
            }
            .modal-header {
                padding: 1rem !important;
            }
            .modal-body {
                padding: 1rem !important;
            }
            .modal-footer {
                padding: 1rem !important;
            }
            
            /* Footer Mobile */
            .main-footer {
                padding: 1rem !important;
                text-align: center !important;
            }
            .main-footer .float-right {
                float: none !important;
                margin-top: 0.5rem !important;
            }
            
            /* Charts Mobile */
            canvas {
                max-height: 300px !important;
            }
            
            /* Search and Filter Mobile */
            .search-box {
                width: 100% !important;
                margin-bottom: 1rem !important;
            }
            .filter-section {
                flex-direction: column !important;
            }
            .filter-section .form-group {
                margin-bottom: 1rem !important;
            }
            
            /* Equal Height Cards Mobile */
            .equal-height-cards .card {
                min-height: auto !important;
            }
            
            /* Breadcrumb Mobile */
            .breadcrumb {
                font-size: 0.85rem !important;
                padding: 0.5rem 0 !important;
            }
            
            /* Badge Mobile */
            .badge {
                font-size: 0.75rem !important;
                padding: 0.25rem 0.5rem !important;
            }
            
            /* Rating Stars Mobile */
            .rating-stars {
                font-size: 1rem !important;
            }
            
        }
        
        /* Extra Small Devices */
        @media (max-width: 576px) {
            .page-title-custom {
                font-size: 1.5rem !important;
            }
            .small-box .inner h3 {
                font-size: 1.5rem !important;
            }
            .table {
                font-size: 0.8rem !important;
            }
            .btn {
                width: 100% !important;
                margin-bottom: 0.5rem !important;
            }
            .navbar-nav .nav-link {
                text-align: center !important;
            }
        }
        
        /* Prevent zoom on input focus (iOS) */
        @media screen and (-webkit-min-device-pixel-ratio: 0) {
            select,
            textarea,
            input {
                font-size: 16px !important;
            }
        }
        
        /* Touch-friendly improvements */
        @media (hover: none) and (pointer: coarse) {
            .nav-link,
            .btn,
            .form-control,
            .form-select {
                min-height: 44px !important;
            }
            
            .table th,
            .table td {
                min-height: 44px !important;
            }
        }
        
        /* Session Expired Alert Styling */
        .session-expired-popup {
            border-radius: 12px !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2) !important;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%) !important;
        }
        
        .session-expired-title {
            color: var(--dark-gray) !important;
            font-family: 'Poppins', sans-serif !important;
            font-weight: 600 !important;
            font-size: 1.5rem !important;
            margin-bottom: 1rem !important;
        }
        
        .session-expired-content {
            color: var(--dark-gray) !important;
            font-family: 'Poppins', sans-serif !important;
            font-size: 1rem !important;
            line-height: 1.5 !important;
        }
        
        /* Custom hourglass icon styling */
        .swal2-icon.swal2-warning {
            border-color: var(--golden-orange) !important;
            color: var(--golden-orange) !important;
        }
        
        .swal2-icon.swal2-warning .swal2-icon-content {
            color: var(--golden-orange) !important;
        }
        
        /* Mobile responsive session alert */
        @media (max-width: 768px) {
            .session-expired-popup {
                margin: 1rem !important;
                width: calc(100% - 2rem) !important;
            }
            
            .session-expired-title {
                font-size: 1.3rem !important;
            }
            
            .session-expired-content {
                font-size: 0.95rem !important;
            }
        }
        
        /* Mobile Table Scrolling Fixes */
        @media (max-width: 768px) {
            .table-responsive {
                -webkit-overflow-scrolling: touch !important;
                overflow-x: auto !important;
                overflow-y: visible !important;
                -webkit-scrollbar-width: thin !important;
                scrollbar-width: thin !important;
            }
            
            .table-responsive::-webkit-scrollbar {
                height: 6px !important;
            }
            
            .table-responsive::-webkit-scrollbar-track {
                background: #f1f1f1 !important;
                border-radius: 3px !important;
            }
            
            .table-responsive::-webkit-scrollbar-thumb {
                background: #c1c1c1 !important;
                border-radius: 3px !important;
            }
            
            .table-responsive::-webkit-scrollbar-thumb:hover {
                background: #a8a8a8 !important;
            }
            
            .table {
                min-width: 600px !important; /* Ensures table doesn't shrink too much */
                white-space: nowrap !important;
            }
            
            .table th,
            .table td {
                white-space: nowrap !important;
                padding: 0.75rem 1rem !important;
                vertical-align: middle !important;
            }
            
            /* DataTables specific mobile fixes */
            .dataTables_wrapper {
                overflow-x: auto !important;
                -webkit-overflow-scrolling: touch !important;
            }
            
            .dataTables_scrollBody {
                overflow-x: auto !important;
                -webkit-overflow-scrolling: touch !important;
            }
            
            .dataTables_scrollHead {
                overflow-x: auto !important;
                -webkit-overflow-scrolling: touch !important;
            }
            
            /* Card body scrolling fix */
            .card-body {
                overflow-x: auto !important;
                -webkit-overflow-scrolling: touch !important;
            }
            
            /* Prevent horizontal scroll on body when table is scrolled */
            body {
                overflow-x: hidden !important;
            }
            
            /* Touch scrolling improvements */
            .table-responsive,
            .dataTables_wrapper,
            .card-body {
                touch-action: pan-x !important;
                -webkit-overflow-scrolling: touch !important;
            }
        }
        
        /* Extra small devices table fixes */
        @media (max-width: 576px) {
            .table {
                min-width: 500px !important;
                font-size: 0.8rem !important;
            }
            
            .table th,
            .table td {
                padding: 0.5rem 0.75rem !important;
            }
            
            .table-responsive {
                margin: 0 -0.5rem !important;
                padding: 0 0.5rem !important;
            }
        }
    </style>
    
    @stack('styles')
</head>

<body class="hold-transition layout-fixed">
    <div class="wrapper">
        <!-- Top Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="{{ route('dashboard') }}">
                <img src="{{ asset('images/logo.png') }}" alt="Sentiment Analysis Engineering">
                <span class="d-none d-md-inline" style="font-family: 'Poppins', sans-serif;">Sentiment Analysis Engineering</span>
            </a>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('survey.index') }}" target="_blank" style="background: linear-gradient(135deg, var(--golden-orange) 0%, var(--light-green) 100%); color: white; border-radius: 8px; padding: 10px 16px; margin-right: 12px; font-weight: 500; transition: all 0.3s ease; border: none; display: flex; align-items: center;">
                        <i class="fas fa-external-link-alt" style="margin-right: 8px;"></i> 
                        <span class="d-none d-sm-inline">Engineering Survey</span>
                        <span class="d-sm-none">Survey</span>
                    </a>
                </li>
                @auth
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" style="color: var(--dark-gray); font-weight: 500; padding: 12px 16px; border-radius: 8px; transition: all 0.3s ease; display: flex; align-items: center; background: rgba(152, 170, 231, 0.1);">
                        <i class="fas fa-user-circle" style="margin-right: 8px; color: var(--light-blue); font-size: 1.1rem;"></i> 
                        <span class="d-none d-sm-inline">{{ Auth::user()->name }}</span>
                        <i class="fas fa-chevron-down" style="margin-left: 8px; font-size: 0.8rem; color: var(--dark-gray);"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" style="border: none; box-shadow: 0 8px 25px rgba(0,0,0,0.15); border-radius: 12px; padding: 8px; min-width: 200px;">
                        <li>
                            <a class="dropdown-item" href="#" onclick="logout()" style="color: var(--dark-gray); padding: 12px 16px; border-radius: 8px; transition: all 0.3s ease; display: flex; align-items: center;">
                                <i class="fas fa-sign-out-alt" style="margin-right: 12px; color: var(--coral-pink);"></i> 
                                <span>Logout</span>
                            </a>
                        </li>
                    </ul>
                </li>
                @endauth
            </ul>
        </nav>

        <!-- Horizontal Navigation Menu -->
        @auth
        <nav class="navbar navbar-expand-lg horizontal-nav">
            <div class="container-fluid">
                <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#horizontalNav" aria-controls="horizontalNav" aria-expanded="false" aria-label="Toggle navigation" style="border: 2px solid rgba(255,255,255,0.3); color: white; padding: 0.5rem 0.75rem;">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="horizontalNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="{{ route('dashboard') }}" class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('subjects.index') }}" class="nav-link {{ request()->routeIs('subjects.*') ? 'active' : '' }}">
                                <i class="fas fa-book"></i>
                                <span>Subjects</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('users.index') }}" class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}">
                                <i class="fas fa-users"></i>
                                <span>Users</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('survey-questions.index') }}" class="nav-link {{ request()->routeIs('survey-questions.*') ? 'active' : '' }}">
                                <i class="fas fa-question-circle"></i>
                                <span>Survey Questions</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('reports.index') }}" class="nav-link {{ request()->routeIs('reports.*') ? 'active' : '' }}">
                                <i class="fas fa-chart-bar"></i>
                                <span>Reports</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('sentiment-words.index') }}" class="nav-link {{ request()->routeIs('sentiment-words.*') ? 'active' : '' }}">
                                <i class="fas fa-brain"></i>
                                <span>Sentiment Words</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        @endauth

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <h1 class="page-title-custom">
                                <i class="fas fa-@yield('icon', 'home')"></i>
                                <span>@yield('page-title', 'Dashboard')</span>
                            </h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb">
                                @yield('breadcrumb')
                            </ol>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle"></i>
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle"></i>
                            {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @yield('content')
                </div>
            </section>
        </div>

        <!-- Footer -->
        <footer class="main-footer">
            <div class="float-right d-none d-sm-inline">
                <span class="text-muted">Sentiment Analysis Engineering</span>
            </div>
            <strong>Copyright &copy; {{ date('Y') }}</strong> All rights reserved.
        </footer>
    </div>

    <!-- Logout Form -->
    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
        @csrf
    </form>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/3.2.0/js/adminlte.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // CSRF Token setup for AJAX
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Global success/error message handlers
        function showSuccess(message) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: message,
                timer: 3000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end',
                            background: '#8EA604',
            color: '#BF3100'
            });
        }

        function showError(message) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: message,
                background: '#FF4E00',
                color: '#fff'
            });
        }

        // Auto-hide alerts after 5 seconds
        $(document).ready(function() {
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);

            // Enhanced modal functionality
            $('.modal').on('shown.bs.modal', function() {
                $(this).find('input:first').focus();
            });

            // Enhanced form validation styling
            $('.form-control').on('focus', function() {
                $(this).parent().addClass('focused');
            }).on('blur', function() {
                if (!$(this).val()) {
                    $(this).parent().removeClass('focused');
                }
            });


            // Session expiration detection
            let sessionTimeout;
            const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes in milliseconds

            function resetSessionTimer() {
                clearTimeout(sessionTimeout);
                sessionTimeout = setTimeout(function() {
                    showSessionExpiredAlert();
                }, SESSION_TIMEOUT);
            }

            function showSessionExpiredAlert() {
                Swal.fire({
                    title: 'Your session has expired',
                    text: 'Due to inactivity, your session has expired. Please refresh to continue.',
                    icon: 'warning',
                    iconColor: '#F5B445',
                    background: '#ffffff',
                    confirmButtonColor: '#98AAE7',
                    confirmButtonText: 'Refresh Page',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showCancelButton: false,
                    customClass: {
                        popup: 'session-expired-popup',
                        title: 'session-expired-title',
                        content: 'session-expired-content'
                    },
                    didOpen: () => {
                        // Add custom styling
                        const popup = Swal.getPopup();
                        popup.style.borderRadius = '12px';
                        popup.style.boxShadow = '0 10px 30px rgba(0,0,0,0.2)';
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.reload();
                    }
                });
            }

            // Reset timer on user activity
            $(document).on('mousemove keypress click scroll', function() {
                resetSessionTimer();
            });

            // Initialize session timer
            resetSessionTimer();

            // Check for server-side session expiration
            $(document).ajaxError(function(event, xhr, settings) {
                if (xhr.status === 419) { // CSRF token mismatch (session expired)
                    showSessionExpiredAlert();
                }
            });
        });

        function logout() {
            Swal.fire({
                title: '<div style="display: flex; align-items: center; justify-content: center; margin-bottom: 10px;">' +
                       '<i class="fas fa-sign-out-alt" style="font-size: 2rem; color: var(--coral-pink); margin-right: 15px;"></i>' +
                       '<span style="font-family: \'Poppins\', sans-serif; font-weight: 600; color: var(--dark-gray);">Confirm Logout</span>' +
                       '</div>',
                html: '<div style="text-align: center; padding: 20px 0;">' +
                      '<p style="font-family: \'Poppins\', sans-serif; font-size: 1.1rem; color: #666; margin-bottom: 15px; line-height: 1.5;">' +
                      'You are about to log out of your account. All unsaved changes will be lost.</p>' +
                      '<div style="background: linear-gradient(135deg, rgba(255, 78, 0, 0.1) 0%, rgba(245, 187, 0, 0.1) 100%); padding: 15px; border-radius: 10px; border-left: 4px solid var(--coral-pink);">' +
                      '<p style="font-family: \'Poppins\', sans-serif; font-size: 0.95rem; color: var(--dark-gray); margin: 0; font-weight: 500;">' +
                      '<i class="fas fa-info-circle" style="color: var(--coral-pink); margin-right: 8px;"></i>' +
                      'You can log back in anytime using your credentials.</p>' +
                      '</div>' +
                      '</div>',
                icon: 'warning',
                iconColor: 'var(--coral-pink)',
                showCancelButton: true,
                confirmButtonColor: 'var(--coral-pink)',
                cancelButtonColor: 'var(--dark-gray)',
                confirmButtonText: '<i class="fas fa-sign-out-alt mr-2"></i>Yes, Log Out',
                cancelButtonText: '<i class="fas fa-times mr-2"></i>Cancel',
                background: '#ffffff',
                backdrop: 'rgba(0, 0, 0, 0.4)',
                allowOutsideClick: false,
                allowEscapeKey: true,
                customClass: {
                    popup: 'logout-confirmation-popup',
                    title: 'logout-confirmation-title',
                    content: 'logout-confirmation-content',
                    confirmButton: 'logout-confirm-btn',
                    cancelButton: 'logout-cancel-btn'
                },
                didOpen: () => {
                    // Add custom styling
                    const popup = Swal.getPopup();
                    popup.style.borderRadius = '16px';
                    popup.style.boxShadow = '0 20px 60px rgba(0,0,0,0.15)';
                    popup.style.border = '1px solid rgba(255, 78, 0, 0.1)';
                    
                    // Style buttons
                    const confirmBtn = Swal.getConfirmButton();
                    const cancelBtn = Swal.getCancelButton();
                    
                    if (confirmBtn) {
                        confirmBtn.style.borderRadius = '8px';
                        confirmBtn.style.fontWeight = '600';
                        confirmBtn.style.fontFamily = '\'Poppins\', sans-serif';
                        confirmBtn.style.padding = '12px 24px';
                        confirmBtn.style.transition = 'all 0.3s ease';
                    }
                    
                    if (cancelBtn) {
                        cancelBtn.style.borderRadius = '8px';
                        cancelBtn.style.fontWeight = '600';
                        cancelBtn.style.fontFamily = '\'Poppins\', sans-serif';
                        cancelBtn.style.padding = '12px 24px';
                        cancelBtn.style.transition = 'all 0.3s ease';
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading state
                    Swal.fire({
                        title: '<div style="display: flex; align-items: center; justify-content: center;">' +
                               '<i class="fas fa-spinner fa-spin" style="font-size: 1.5rem; color: var(--coral-pink); margin-right: 10px;"></i>' +
                               '<span style="font-family: \'Poppins\', sans-serif; font-weight: 600; color: var(--dark-gray);">Logging Out...</span>' +
                               '</div>',
                        html: '<p style="font-family: \'Poppins\', sans-serif; color: #666; margin-top: 10px;">Please wait while we securely log you out.</p>',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        showConfirmButton: false,
                        background: '#ffffff',
                        customClass: {
                            popup: 'logout-loading-popup'
                        },
                        didOpen: () => {
                            const popup = Swal.getPopup();
                            popup.style.borderRadius = '16px';
                            popup.style.boxShadow = '0 20px 60px rgba(0,0,0,0.15)';
                        }
                    });
                    
                    $.ajax({
                        url: "{{ route('logout') }}",
                        type: 'POST',
                        data: {
                            _token: "{{ csrf_token() }}"
                        },
                        success: function(response) {
                            if (response.success) {
                                Swal.fire({
                                    title: '<div style="display: flex; align-items: center; justify-content: center; margin-bottom: 10px;">' +
                                           '<span style="font-family: \'Poppins\', sans-serif; font-weight: 600; color: var(--dark-gray);">Logout Complete</span>' +
                                           '</div>',
                                    html: '<p style="font-family: \'Poppins\', sans-serif; color: #666; margin-bottom: 15px;">Your session has been terminated successfully.</p>' +
                                          '<p style="font-family: \'Poppins\', sans-serif; color: #666; font-size: 0.9rem;">Taking you to the login screen...</p>',
                                    icon: 'success',
                                    iconColor: 'var(--light-green)',
                                    background: '#ffffff',
                                    confirmButtonColor: 'var(--light-green)',
                                    confirmButtonText: '<i class="fas fa-sign-in-alt mr-2"></i>Continue',
                                    allowOutsideClick: false,
                                    allowEscapeKey: false,
                                    showCancelButton: false,
                                    customClass: {
                                        popup: 'logout-success-popup'
                                    },
                                    didOpen: () => {
                                        const popup = Swal.getPopup();
                                        popup.style.borderRadius = '16px';
                                        popup.style.boxShadow = '0 20px 60px rgba(0,0,0,0.15)';
                                    }
                                }).then(() => {
                                    window.location.href = "{{ url('/login') }}";
                                });
                            } else {
                                showError(response.message || 'Logout failed. Please try again.');
                            }
                        },
                        error: function(xhr, status, error) {
                            showError('Network error or server issue. Please check your connection and try again.');
                        }
                    });
                }
            });
        }
    </script>

    @stack('scripts')
</body>
</html> 